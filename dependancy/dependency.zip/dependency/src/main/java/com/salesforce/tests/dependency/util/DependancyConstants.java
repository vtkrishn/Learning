package com.salesforce.tests.dependency.util;

public interface DependancyConstants {
	public String SPACE = " ";
}
