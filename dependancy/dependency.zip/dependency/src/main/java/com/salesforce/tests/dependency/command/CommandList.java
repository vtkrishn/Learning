package com.salesforce.tests.dependency.command;

public interface CommandList {
	String DEPEND = "DEPEND";
	String INSTALL = "INSTALL";
	String REMOVE = "REMOVE";
	String LIST = "LIST";
	String END = "END";
}
