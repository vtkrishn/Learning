package com.salesforce.tests.dependency.command;

public class ENDCommand implements Command{
	@Override
	public void execute(CommandOptions options) {
		// TODO Auto-generated method stub
		
	}
}
