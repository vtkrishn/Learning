const mongoose = require('mongoose');

// User Schema
const userSchema = mongoose.Schema({
	name:{
		type: String,
		required: true
	},
	email:{
		type: String,
		default: true
	}
});

const User = module.exports = mongoose.model('User', userSchema);

// Get All Users
module.exports.getUsers =

// Get User
module.exports.getUserById =

// Add User
module.exports.addUser =

// Update User
module.exports.updateUser =

// Delete User
module.exports.removeUser =
