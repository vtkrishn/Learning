<template>
  <q-page class="q-pa-lg">
   <h5 class="q-mt-none">Help</h5>
   <p>For help contact <a href="mailto:tllos1@uis.edu">Tulio Llosa</a>.</p>
  </q-page>
</template>

<script>
export default {
  
}
</script>
