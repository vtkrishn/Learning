const mongoose = require('mongoose');

// Blog Schema
const blogSchema = mongoose.Schema({
	title:{
		type: String,
		required: true
	},
	body:{
		type: String,
		required: true
	},
	slug:{
		type: String,
		required: true
	},
	author:{
		type: mongoose.ObjectId,
		ref: 'User'
	},
	comments:[{
			user_id : {
				type: mongoose.ObjectId,
				ref: 'User'
			},
			comment : {
				type: String,
				required: true
			},
			approved: {
				type: Boolean,
				default: false
			},
			created_at : {
				type: Date,
				default: Date.now
			}
	}],
	category : [{
		name: String
	}]
});

const Blog = module.exports = mongoose.model('Blog', blogSchema);

// Get All Blog - find method
module.exports.getBlogs = (callback, limit) => {
        Blog.find(callback)
				.sort({'comments.created_at': 'descending'})
				.populate('author')
				.limit(limit);
}

// Get Blog - findById method
module.exports.getBlogById = (id,callback) => {
	  Blog.findById(id)
		.populate('author')
		.exec(callback);
}

module.exports.getBlogByUserId = (id,callback) => {
	  Blog.find({'author' : {'_id' : id}}, callback);
}

// Add Blog - create method
module.exports.addBlog = (blog,callback) => {
	Blog.create(blog, callback);
}

// Update Blog - findOneAndUpdate method
module.exports.updateBlog = (id,blog,options,callback) => {
	Blog.findOneAndUpdate({'_id' : id},blog,options, callback);
}

// Delete Blog - deleteOne method
module.exports.removeBlog = (id,callback) => {
	Blog.deleteOne({'_id' : id}, callback);
}
