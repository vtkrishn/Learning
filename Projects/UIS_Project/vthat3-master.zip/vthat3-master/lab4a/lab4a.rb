#Your code goes here
import 'org.apache.hadoop.hbase.client.HTable'
import 'org.apache.hadoop.hbase.client.Put'

def jbytes(*args)
  args.map { |arg| arg.to_s.to_java_bytes }
end

def put_many(table_name, row, column_values)
    table = HTable.new( @hbase.configuration, table_name)
    column_values.each {
      |item|
      answer = item[1]
      splits = item[0].split(":")
      p = Put.new(*jbytes(row))
      key = splits[0]
      value = splits[1]
      if value == nil
        value = ""
      end
      p.add(*jbytes(key,value,answer))
      table.put(p)
    }
end

put_many 'wiki', 'NoSQL', {
"text:" => "What was your last project in the course?",
"revision:author" => "Vinod Krishnan",
"revision:comment" => "User Blog site using Mongoose"
}

get 'wiki', 'NoSQL'

#Do not remove the exit call below
exit
