# CSC 561A: NoSQL Databases

#### 20SU - NOSQL DATABASES (20SU-OL-CSC561A-12195)

---

Lab6a:

<img src="https://csc570e.uis.edu/api/badges/CSC561A-420205/vthat3/status.svg?branch=master">

