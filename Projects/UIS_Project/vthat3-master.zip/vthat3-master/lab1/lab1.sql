-- LAB1 Part 1-A Started
--createdb book
--psql book -c "SELECT '1'::cube;"
--psql book

--\h CREATE INDEX

--Note: All the tables were already created so reused the already existing tables

--CREATE TABLE countries (
--country_code char(2) PRIMARY KEY,
--country_name text UNIQUE);
--ERROR:  relation "countries" already exists

--INSERT INTO countries (country_code, country_name)
--VALUES ('us', 'United States'), ('mx', 'Mexico'), ('au', 'Australia'),
--('gb', 'United Kingdom'), ('de', 'Germany'), ('ll', 'Loompaland');
--ERROR:  duplicate key value violates unique constraint "countries_pkey"
--DETAIL:  Key (country_code)=(us) already exists.

--DELETE FROM countries WHERE country_code = 'll';

--book=# SELECT * FROM countries;
-- country_code |  country_name
--------------+----------------
-- us           | United States
-- mx           | Mexico
-- au           | Australia
-- gb           | United Kingdom
-- de           | Germany
--(5 rows)

--CREATE TABLE cities(
--name text NOT NULL,
--postal_code varchar(9) CHECK (postal_code <> ''),
--country_code char(2) REFERENCES countries,
--PRIMARY KEY (country_code, postal_code)
--);

---INSERT INTO cities VALUES ('Toronto', 'M4C1B5', 'ca');
--INSERT INTO cities VALUES ('Portland', '87200', 'us');

--UPDATE cities
--SET postal_code = '97205'
--WHERE name = 'Portland';

--select * from cities;
--name   | postal_code | country_code
----------+-------------+--------------
--Portland | 97205       | us
--(1 row)

--SELECT cities.*, country_name FROM cities INNER JOIN countries ON cities.country_code = countries.country_code;
--   name   | postal_code | country_code | country_name
----------+-------------+--------------+---------------
-- Portland | 97205       | us           | United States


-- CREATE TABLE venues (
-- venue_id SERIAL PRIMARY KEY,
-- name varchar(255),
-- street_address text,
-- type char(7) CHECK ( type in ('public','private') ) DEFAULT 'public',
-- postal_code varchar(9),
-- country_code char(2),
-- FOREIGN KEY (country_code, postal_code)
-- REFERENCES cities(country_code, postal_code) MATCH FULL
-- );

--INSERT INTO venues (name, postal_code, country_code)
 --VALUES ('Crystal Ballroom', '97205', 'us');

--INSERT INTO venues (name, postal_code, country_code)
 --VALUES ('Voodoo Donuts','97205','us') RETURNING venue_id;

 --SELECT v.venue_id, v.name, c.name
 --FROM venues v INNER JOIN cities c
  --on v.postal_code=c.postal_code AND v.country_code=c.country_code;
  --venue_id |       name       |   name
 ----------+------------------+----------
    --     2 | Voodoo Donuts    | Portland
    --     1 | Crystal Ballroom | Portland
 --(2 rows)

 --\q
 -- LAB1 Part 1-A Ended
--LAB1 Part 1-B Started
--
-- createdb lab1
-- psql lab1

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  first_name varchar(30),
  last_name varchar(30),
  email text NOT NULL UNIQUE,
  password text NOT NULL,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

INSERT INTO users (first_name,last_name,email,password,created_at,updated_at) VALUES ('Alice','Mark','alicemark@abc.com','password','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO users (first_name,last_name,email,password,created_at,updated_at) VALUES ('Bob','Nova','bobnova@abc.com','password','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO users (first_name,last_name,email,password,created_at,updated_at) VALUES ('Cathy','olive','cathyolive@abc.com','password','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO users (first_name,last_name,email,password,created_at,updated_at) VALUES ('Doug','Pug','dougpug@abc.com','password','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO users (first_name,last_name,email,password,created_at,updated_at) VALUES ('Elsa','Quine','elsaquine@abc.com','password','2020-06-01 17:30','2020-06-01 17:30');

--lab1=# select * from users;
--id | first_name | last_name |       email        | password |     created_at      |     updated_at
----+------------+-----------+--------------------+----------+---------------------+---------------------
 --1 | Alice      | Mark      | alicemark@abc.com  | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
 --2 | Bob        | Nova      | bobnova@abc.com    | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
 --3 | Cathy      | olive     | cathyolive@abc.com | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
 --4 | Doug       | Pug       | dougpug@abc.com    | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
 --5 | Elsa       | Quine     | elsaquine@abc.com  | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--(5 rows)

CREATE TABLE status (
  id SERIAL PRIMARY KEY,
  description varchar(15) NOT NULL CHECK ( description in ('Available','Checked out','Overdue','Unavailable','Under Repair') ) DEFAULT 'Available',
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

INSERT INTO status (description,created_at,updated_at) VALUES ('Available','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO status (description,created_at,updated_at) VALUES ('Checked out','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO status (description,created_at,updated_at) VALUES ('Overdue','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO status (description,created_at,updated_at) VALUES ('Unavailable','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO status (description,created_at,updated_at) VALUES ('Under Repair','2020-06-01 17:30','2020-06-01 17:30');

--lab1=# select * from status;
 --id | description  |     created_at      |     updated_at
----+--------------+---------------------+---------------------
--  1 | Available    | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  2 | Checked out  | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  3 | Overdue      | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  4 | Unavailable  | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  5 | Under Repair | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--(5 rows)

CREATE TABLE inventory (
  id SERIAL PRIMARY KEY,
  status_id integer,
  description varchar(15) NOT NULL CHECK ( description in ('Laptop1','Laptop2','Webcam1','TV1','Microphone1') ) DEFAULT 'Laptop1',
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  FOREIGN KEY (status_id)
  REFERENCES status(id) MATCH FULL
);

INSERT INTO inventory (status_id,description,created_at,updated_at) VALUES (1,'Laptop1','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO inventory (status_id,description,created_at,updated_at) VALUES (2,'Laptop2','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO inventory (status_id,description,created_at,updated_at) VALUES (3,'Webcam1','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO inventory (status_id,description,created_at,updated_at) VALUES (4,'TV1','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO inventory (status_id,description,created_at,updated_at) VALUES (5,'Microphone1','2020-06-01 17:30','2020-06-01 17:30');

--lab1=# select * from inventory;
 --id | status_id | description |     created_at      |     updated_at
----+-----------+-------------+---------------------+---------------------
--  1 |         1 | Laptop1     | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  2 |         2 | Laptop2     | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  3 |         3 | Webcam1     | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  4 |         4 | TV1         | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  5 |         5 | Microphone1 | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--(5 rows)

CREATE TABLE transactions (
  id SERIAL PRIMARY KEY,
  user_id integer,
  inventory_id integer,
  checkout_time TIMESTAMP NOT NULL,
  scheduled_checkin_time TIMESTAMP,
  actual_checkin_time TIMESTAMP,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  FOREIGN KEY (user_id)
  REFERENCES users(id) MATCH FULL,
  FOREIGN KEY (inventory_id)
  REFERENCES inventory(id) MATCH FULL
);

INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (1,1,'2020-06-01 17:30','2020-07-01 17:30','2020-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (2,2,'2019-06-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (1,3,'2018-06-01 17:30','2018-07-01 17:30','2018-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');

UPDATE inventory SET status_id=2 where id in (select inventory_id from transactions);

--lab1=# select * from transactions;
--id | user_id | inventory_id |    checkout_time    | scheduled_checkin_time | actual_checkin_time |     created_at      |     updated_at
----+---------+--------------+---------------------+------------------------+---------------------+---------------------+---------------------
-- 1 |       1 |            1 | 2020-06-01 17:30:00 | 2020-07-01 17:30:00    | 2020-08-01 17:30:00 | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
-- 2 |       2 |            2 | 2019-06-01 17:30:00 | 2019-07-01 17:30:00    | 2019-08-01 17:30:00 | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
-- 3 |       1 |            3 | 2018-06-01 17:30:00 | 2018-07-01 17:30:00    | 2018-08-01 17:30:00 | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--(3 rows)

ALTER TABLE users ADD COLUMN signed_agreement boolean DEFAULT false;

--lab1=# select * from users;
--id | first_name | last_name |       email        | password |     created_at      |     updated_at      | signed_agreement
----+------------+-----------+--------------------+----------+---------------------+---------------------+------------------
-- 1 | Alice      | Mark      | alicemark@abc.com  | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00 | f
-- 2 | Bob        | Nova      | bobnova@abc.com    | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00 | f
-- 3 | Cathy      | olive     | cathyolive@abc.com | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00 | f
-- 4 | Doug       | Pug       | dougpug@abc.com    | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00 | f
-- 5 | Elsa       | Quine     | elsaquine@abc.com  | password | 2020-06-01 17:30:00 | 2020-06-01 17:30:00 | f
--(5 rows)


SELECT inv.description,ts.scheduled_checkin_time from inventory inv
JOIN transactions ts on
inv.id = ts.inventory_id
order by ts.scheduled_checkin_time desc;

--lab1=# SELECT inv.description,ts.scheduled_checkin_time from inventory inv JOIN
--transactions ts on inv.id = ts.inventory_id order by ts.scheduled_checkin_time desc;
-- description | scheduled_checkin_time
-------------+------------------------
-- Laptop1     | 2020-07-01 17:30:00
-- Laptop2     | 2019-07-01 17:30:00
-- Webcam1     | 2018-07-01 17:30:00
--(3 rows)

SELECT inv.description,ts.scheduled_checkin_time from inventory inv
JOIN transactions ts on
inv.id = ts.inventory_id
where ts.scheduled_checkin_time > '2019-05-31';

--lab1=# SELECT inv.description,ts.scheduled_checkin_time from inventory inv JOIN
--transactions ts on inv.id = ts.inventory_id where ts.scheduled_checkin_time > '2019-05-31';
-- description | scheduled_checkin_time
-------------+------------------------
-- Laptop1     | 2020-07-01 17:30:00
-- Laptop2     | 2019-07-01 17:30:00
-- (2 rows)

SELECT count(inv.description) from inventory inv
JOIN transactions ts on
inv.id = ts.inventory_id
JOIN status st on
inv.status_id = st.id
where ts.user_id = 1 and st.description='Checked out';

--count
-------
--    0
--(1 row)

-- UPDATE inventory SET status_id=2 where id in (select inventory_id from transactions);

---lab1=# UPDATE inventory SET status_id=2 where id in (select inventory_id from transactions);
--UPDATE 3
--lab1=# select * from inventory;
-- id | status_id | description |     created_at      |     updated_at
----+-----------+-------------+---------------------+---------------------
--  4 |         4 | TV1         | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  5 |         5 | Microphone1 | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  1 |         2 | Laptop1     | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  2 |         2 | Laptop2     | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--  3 |         2 | Webcam1     | 2020-06-01 17:30:00 | 2020-06-01 17:30:00
--(5 rows)


--lab1=# SELECT count(inv.description) from inventory inv  JOIN transactions ts on inv.id = ts.inventory_id JOIN status st on inv.status_id = st.id where ts.user_id = 1 and st.description='Checked out';
-- count
-------
--     2
--(1 row)

--ALTER TABLE status ALTER COLUMN description TYPE varchar(15);
--ALTER TABLE status ADD CHECK (description IN('Available','Checked out','Overdue','Unavailable','Under Repair'));
--ALTER TABLE inventory ALTER COLUMN description TYPE varchar(15);
--ALTER TABLE inventory ADD CHECK (description IN('Laptop1','Laptop2','Webcam1','TV1','Microphone1'));
--ALTER TABLE users ADD COLUMN signed_agreement boolean DEFAULT false;

-- LAB1 Part 1-B Ended
-- LAB1 Part 2-A Started
--A
--insert into cities values ('Springfield', '62703', 'us');
--insert into venues (name, postal_code, country_code) values ('Sangamon Auditorium', '62703', 'us');

-- CREATE TABLE events (
--  event_id SERIAL PRIMARY KEY,
--    title varchar(50) NOT NULL,
--    starts TIMESTAMP,
--    ends TIMESTAMP,
--    venue_id integer,
--    FOREIGN KEY (venue_id)
--    REFERENCES venues(venue_id) MATCH FULL
--  );

--insert into events (title, starts, ends, venue_id) values ('Coldplay Concert', '2015-12-31 21:00:00','2015-12-31 23:30:00',(select venue_id from venues where name = 'Crystal Ballroom'));
--book=# select * from events;
--event_id |      title       |       starts        |        ends         | venue_id
----------+------------------+---------------------+---------------------+----------
--       1 | Coldplay Concert | 2015-12-31 21:00:00 | 2015-12-31 23:30:00 |       1
--(1 row)
-- book=# select count(*) from events;
-- count
-------
--     1
--(1 row)

--SELECT count(*) FROM events WHERE venue_id = 1;
--SELECT count(*) FROM events WHERE venue_id = 2;
--SELECT count(*) FROM events WHERE venue_id = 3;
--SELECT count(*) FROM events WHERE venue_id IS NULL;

--SELECT venue_id FROM events GROUP BY venue_id;
--venue_id
----------
--       1
--(1 row)
--
--SELECT DISTINCT venue_id FROM events;
--venue_id
----------
--       1
--(1 row)
--

-- Remaining excercise completed in the Adminer Web Version

-- LAB1 Part 2-A Ended
-- LAB1 Part 2-B Started

-- 3 rows actual_checkin_time after scheduled_checkin_time
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (2,1,'2020-06-01 17:30','2020-07-01 17:30','2020-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (2,2,'2019-06-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (2,3,'2018-06-01 17:30','2018-07-01 17:30','2018-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');

-- 5 checkout_time > september 3 2018
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (1,4,'2019-06-01 17:30','2018-07-01 17:30','2018-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (1,5,'2019-07-01 17:30','2018-07-01 17:30','2018-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (2,4,'2020-01-01 17:30','2020-07-01 17:30','2020-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (2,5,'2019-02-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (3,1,'2019-03-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');

-- Remaining records
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (3,2,'2019-06-01 17:30','2018-07-01 17:30','2018-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (3,3,'2019-07-01 17:30','2018-07-01 17:30','2018-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (3,4,'2020-01-01 17:30','2020-07-01 17:30','2020-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (3,5,'2018-02-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (4,1,'2018-03-01 17:30','2019-06-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (4,2,'2017-03-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (4,3,'2016-03-01 17:30','2019-08-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (4,4,'2019-03-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (4,5,'2018-07-01 17:30','2019-05-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (5,1,'2015-06-01 17:30','2019-05-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (5,2,'2011-05-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');
INSERT INTO transactions (user_id,inventory_id,checkout_time,scheduled_checkin_time,actual_checkin_time,created_at,updated_at) VALUES (5,3,'2019-04-01 17:30','2019-07-01 17:30','2019-08-01 17:30','2020-06-01 17:30','2020-06-01 17:30');

--select t.user_id as User,
--i.description as Item ,
--count(i.id) as Count,
--max(t.scheduled_checkin_time) as scheduled,
--min(t.actual_checkin_time) as actual
 --from transactions t join inventory i
--on t.inventory_id = i.id
--group by t.user_id, i.description
--having min(t.actual_checkin_time) > max(t.scheduled_checkin_time)
--order by t.user_id

CREATE OR REPLACE VIEW late_checkin AS
select t.user_id as User,
i.description as Item ,
count(i.id) as Count
from transactions t join inventory i on t.inventory_id = i.id
group by t.user_id, i.description  having min(t.actual_checkin_time) > max(t.scheduled_checkin_time)
order by t.user_id

-- completed with setting up the relationship
-- written  query 1 and query 2
-- LAB1 Part 2-B Ended
---
