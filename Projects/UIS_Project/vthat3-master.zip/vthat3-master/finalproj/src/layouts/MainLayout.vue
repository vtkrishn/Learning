<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn
          flat
          dense
          round
          icon="menu"
          aria-label="Menu"
          @click="leftDrawerOpen = !leftDrawerOpen"/>
<q-icon name='img:https://uisgithub1.uis.edu/avatars/u/124?s=460' style="font-size:2em;"/>
        <q-toolbar-title>
          Hi vthat3, Tech Support App
        </q-toolbar-title>

        <div>{{ today }}</div>
      </q-toolbar>
    </q-header>

<q-drawer
        v-model="leftDrawerOpen"
        show-if-above

        :mini="miniState"
        @mouseover="miniState = false"
        @mouseout="miniState = true"
        mini-to-overlay

        :width="200"
        :breakpoint="500"
        bordered
        content-class="bg-grey-3"
      >
        <q-scroll-area class="fit">
          <q-list padding>
            <q-item
		to="/"
                exact
		clickable v-ripple>
              <q-item-section avatar>
                <q-icon name="list" />
              </q-item-section>

              <q-item-section>
                Index
              </q-item-section>
            </q-item>

            <q-item
    to="/admin"
                exact
    clickable v-ripple>
              <q-item-section avatar>
                <q-icon name="how_to_reg" />
              </q-item-section>

              <q-item-section>
                Admin
              </q-item-section>
            </q-item>

            <q-item
    to="/analytics"
                exact
    clickable v-ripple>
              <q-item-section avatar>
                <q-icon name="analytics" />
              </q-item-section>

              <q-item-section>
                Analytics
              </q-item-section>
            </q-item>

            <q-item
            to="/account"
            exact
            active clickable v-ripple>
              <q-item-section avatar>
                <q-icon name="account_circle" />
              </q-item-section>

              <q-item-section>
               Account
              </q-item-section>
            </q-item>

            <q-item
		to="/help"
		exact
		active clickable v-ripple>
              <q-item-section avatar>
                <q-icon name="help" />
              </q-item-section>

              <q-item-section>
               Help
              </q-item-section>
            </q-item>

          </q-list>
        </q-scroll-area>

        <!--
          in this case, we use a button (can be anything)
          so that user can switch back
          to mini-mode
        -->
        <div class="q-mini-drawer-hide absolute" style="top: 15px; right: -17px">
          <q-btn
            dense
            round
            unelevated
            color="accent"
            icon="chevron_left"
            @click="miniState = true"
          />
        </div>
      </q-drawer>
    <q-page-container>
    <keep-alive>
      <router-view />
    </keep-alive>
    </q-page-container>
  </q-layout>
</template>

<script>
import { date } from 'quasar'

function formatDate(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return (date.getMonth()+1) + "/" + date.getDate() + "/" + date.getFullYear() + "  " + strTime;
}

export default {
  name: 'MainLayout',

  components: {
  },

  data () {
    return {
      leftDrawerOpen: false,
      miniState: true,
      currentTime : null
    }
  },
  methods: {
    updateCurrentTime() {
      this.currentTime = moment().format('LTS');
    }
  },
  created() {
    this.currentTime = moment().format('LTS');
    setInterval(() => this.updateCurrentTime(), 1 * 1000);
  }

,
computed: {
today(){
let timeStamp = Date.now()
//return formatDate(new Date());
return date.formatDate(timeStamp, 'dddd MMMM Do YYYY');
}
}
}
</script>
