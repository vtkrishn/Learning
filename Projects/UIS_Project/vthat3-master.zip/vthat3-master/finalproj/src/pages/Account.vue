<template>
<div>
  <q-page class="q-pa-lg">
   <h5 class="q-mt-none">Account</h5>
<q-btn label="Create Account" color="primary" @click="prompt = true" />
  </q-page>

  <q-dialog v-model="prompt" persistent>
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">Create Account</div>
        </q-card-section>

        <q-card-section class="q-pt-none">
          <q-input dense v-model="email" label="Email" autofocus @keyup.enter="prompt = false" />
          <q-input dense v-model="password" type="password" label="Password" autofocus @keyup.enter="prompt = false" />
        </q-card-section>

        <q-card-actions align="right" class="text-primary">
          <q-btn flat label="Create Account"  @click="createAccount" v-close-popup />
          <q-btn flat label="Cancel" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
    </div>
</template>
<script>
export default {
  data () {
    return {
      alert: false,
      confirm: false,
      prompt: false,

      email: '',
      password: ''
    }
  },
  methods: {
async  createAccount(){
  //firebaseApp.auth().signInWithEmailAndPassword(this.email, this.password);
  }
  }
}
</script>
