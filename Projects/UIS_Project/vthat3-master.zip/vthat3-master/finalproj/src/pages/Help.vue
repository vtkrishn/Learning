<template>
  <q-page class="q-pa-lg">
   <h5 class="q-mt-none">Help</h5>
   <a  href="https://uisgithub1.uis.edu/CSC561A-420205/vthat3"><img src="https://uisgithub1.uis.edu/avatars/u/124?s=460" alt="vthat3" width="30"/></a>
   <p>For help contact <a href="mailto:vthat3@uis.edu">Vinod Krishnan</a>.</p>
  </q-page>
</template>

<script>
export default {

}
</script>
