<template>
  <q-page class="bg-grey-3 column">
  <div class="row q-pa-sm bg-primary">
  </div>


 <div class="q-pa-md q-gutter-md">
    <q-list bordered separator class="bg-white rounded-borders">
<q-btn round dense flat @click="refresh" icon="refresh" />
      <q-item-label header>Customer's Waiting to process</q-item-label>

      <q-item
	v-for="user in ActiveUsernames"
        :key="user.id"
	clickable v-ripple>
        <q-item-section avatar>
          <q-avatar>
            <img src="~assets/generic_avatar.png">
          </q-avatar>
        </q-item-section>

        <q-item-section>
          <q-item-label lines="1">{{ user.name }} </q-item-label>
          <q-item-label overline lines="2">{{ user.phone}} </q-item-label>
          <q-item-label caption lines="2">
	  Walk-in
          </q-item-label>
        </q-item-section>



        <q-item-section side bottom>
          <q-btn round dense flat @click="process(user.id)" icon="how_to_reg" />
        </q-item-section>
      </q-item>


    </q-list>
</div>

<div class="q-pa-md q-gutter-md">
   <q-list bordered separator class="bg-white rounded-borders">
     <q-item-label header>Processed Customers</q-item-label>

     <q-item
 v-for="user in NonActiveUsernames"
       :key="user.id"
 clickable v-ripple>
       <q-item-section avatar>
         <q-avatar>
           <img src="~assets/generic_avatar.png">
         </q-avatar>
       </q-item-section>

       <q-item-section>
         <q-item-label lines="1">{{ user.name }} </q-item-label>
         <q-item-label overline lines="2">{{ user.phone}} </q-item-label>
         <q-item-label caption lines="2">
   Walk-in
         </q-item-label>
       </q-item-section>


       <q-item-section side bottom>
         <q-btn round dense flat @click="cancel(user.id)" icon="delete" />
       </q-item-section>
     </q-item>


   </q-list>
</div>

  </q-page>
</template>

<script>
import { date } from 'quasar'
import db from 'boot/firebase'
export default {

 data() {
return{
username: '',
phone: '',
usernames: [],
}
},
methods: {
async initialize()
{
await db.collection('waiting_details').orderBy("timestamp", "asc").onSnapshot(snapshot => {
          snapshot.docChanges().forEach(change => {
            if (change.type === 'added') {
            //ADD
	    const source = change.doc.metadata.hasPendingWrites ? 'Local' : 'Server'
      if (source === 'Server') {
				let user = change.doc.data();
				user.id = change.doc.id;
				this.usernames.push(user);
        }
	    }

	    if (change.type === 'modified') {
              //UPDATE
      const index = this.usernames.findIndex(item => item.id == change.doc.id)
				let user = change.doc.data();
				user.id = change.doc.id;
	    			this.usernames.splice(index, 1, user)
            }

	    if (change.type === 'removed') {
              //REMOVE
      const index = this.usernames.findIndex(item => item.id == change.doc.id)
      if (index >= 0) {
	     this.usernames.splice(index, 1)
             }
	}

          })
        })
},
async refresh() {
this.usernames = [];
this.initialize();
},
async process(id) {
await db.collection('waiting_details').doc(id).update({
active : false,
timestamp: Date.now()
}).then()
.catch((error) => {})
},

async cancel(id) {
await db.collection('waiting_details').doc(id).delete().then()
.catch((error) => {})
}
},
computed: {
ActiveUsernames: function () {
return this.usernames.filter(status => status.active == true)
  },
  NonActiveUsernames: function () {
  return this.usernames.filter(status => status.active != true)
    }
},
created() {
this.initialize();
},
}
</script>
