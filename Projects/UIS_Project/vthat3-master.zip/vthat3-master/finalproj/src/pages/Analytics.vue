<template>
  <q-page class="bg-grey-3 column">
  <div class="q-pa-md q-gutter-md">
     <q-list bordered separator class="bg-white rounded-borders">
       <q-item-label header>Number of users in queue :: {{ActiveUsernames.length}}</q-item-label>
       <q-item-label header>Number of users processed :: {{mostReason.length}}</q-item-label>
     </q-list>
 </div>

  </q-page>
</template>

<script>
import { date } from 'quasar'
import db from 'boot/firebase'
export default {

 data() {
return{
username: '',
phone: '',
usernames: [],
}
},
methods: {
async initialize()
{
await db.collection('waiting_details').orderBy("timestamp", "asc").onSnapshot(snapshot => {
          snapshot.docChanges().forEach(change => {
            if (change.type === 'added') {
            //ADD
	    const source = change.doc.metadata.hasPendingWrites ? 'Local' : 'Server'
      if (source === 'Server') {
				let user = change.doc.data();
				user.id = change.doc.id;
				this.usernames.push(user);
        }
	    }

	    if (change.type === 'modified') {
              //UPDATE
      const index = this.usernames.findIndex(item => item.id == change.doc.id)
				let user = change.doc.data();
				user.id = change.doc.id;
	    			this.usernames.splice(index, 1, user)
            }

	    if (change.type === 'removed') {
              //REMOVE
      const index = this.usernames.findIndex(item => item.id == change.doc.id)
      if (index >= 0) {
	     this.usernames.splice(index, 1)
             }
	}

          })
        })
},
async refresh() {
this.usernames = [];
this.initialize();
},
async process(id) {
await db.collection('waiting_details').doc(id).update({
active : false,
timestamp: Date.now()
}).then()
.catch((error) => {})
},

async cancel(id) {
await db.collection('waiting_details').doc(id).delete().then()
.catch((error) => {})
},
mostReason() {
m = {}
for (var i = 0;i< this.usernames.length;i++){
 if (m.has(item.reason)){
    var val = m[item.reason]
    m[item.reason] = val + 1
 }
 else{
    m[item.reason] = 1
 }
}
}
},
computed: {
ActiveUsernames: function () {
return this.usernames.filter(status => status.active == true)
  },
  NonActiveUsernames: function () {
  return this.usernames.filter(status => status.active != true)
    },

},
created() {
this.initialize();
},
}
</script>
