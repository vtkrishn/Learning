<template>
<div>
  <q-page class="q-pa-lg">
   <h5 class="q-mt-none">Login</h5>
   <q-input dense v-model="email" label="Email" maxlength="10" autofocus @keyup.enter="prompt = false" />
   <q-input dense v-model="password" type="password" label="Password" autofocus @keyup.enter="prompt = false" />
   <q-btn flat label="Login"  @click="login" v-close-popup />
  </q-page>





    </div>
</template>
<script>
export default {
  data () {
    return {
      alert: false,
      confirm: false,
      prompt: false,

      email: '',
      password: ''
    }
  },
  methods: {
async  createAccount(){
  //firebaseApp.auth().signInWithEmailAndPassword(this.email, this.password);
  }
  }
}
</script>
