<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CSC561 | Lab1c</title>
  </head>
<body>

<h3>Status of all of our inventory items - (Inventory -> { belongsTo } -> Status)</h3>

<table border="1">
				<thead>
                    <th>Inventory Item</th>
					<th>Description</th>
				</thead>

				<tbody>
					@foreach ($inventories as $inventory)
                    <tr>
                            <td>{{ $inventory->description }}</td>
							<td>{{ $inventory->status->description }}</td>
                    </tr>
                     @endforeach

                </tbody>
</table>

<h3>Inventory Items that have a status of Checked Out - (Status -> { hasMany } -> Inventory)</h3>

<table border="1">
				<thead>
          <th>Inventory Item</th>
					<th>Description</th>
				</thead>

				<tbody>
					@foreach ($statuses->where('description', 'Checked out')->first()->inventory as $checked_out_inventory)
                    <tr>
                            <td>{{ $checked_out_inventory->description }}</td>
							<td>{{ $checked_out_inventory->status->description }}</td>
                    </tr>
                     @endforeach

                </tbody>
</table>

<h3>Users Transaction - (User -> { hasMany } -> Transaction)</h3>

<table border="1">
				<thead>
          <th>User</th>
					<th>Description</th>
          	<th>Checkout Time</th>
				</thead>

				<tbody>
					@foreach ($users->where('id', '1')->first()->transactions as $user_transactions)
                    <tr>
                            <td>{{ $user_transactions->user_id }}</td>
              <td>{{ $user_transactions->inventory->description }}</td>
              <td>{{ $user_transactions->checkout_time }}</td>
                    </tr>
                     @endforeach

                </tbody>
</table>

<table border="1">
				<thead>
          <th>User First Name</th>
					<th>Description</th>
          	<th>Checkout Time</th>
            <th>Status</th>
				</thead>

				<tbody>
					@foreach ($transactions->where('checkout_time','<',date('2018-09-03'.' 00:00:00')) as $transaction_user)
                    <tr>
                            <td>{{ $transaction_user->user->first_name }}</td>
                            <td>{{ $transaction_user->inventory->description }}</td>
                            <td>{{ $transaction_user->checkout_time }}</td>
                            <td>{{ $transaction_user->inventory->status->description }}</td>
                    </tr>
                     @endforeach

                </tbody>
</table>

</body>
</html>
