php artisan make:model Transaction -cr
php artisan make:model Status
php artisan make:model Inventory

$transactions = Transaction::all();

https://csc570e.uis.edu:9443/csc561/
