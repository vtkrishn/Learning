# 1. CREATE Movies

curl -X PUT http://riak:8098/riak/movies/Titanic -H "Content-Type: application/json" -d '{ "genre" : "drama", "running_time" : "1.15" , "release_date" : "2007" }'

curl -X PUT http://riak:8098/riak/movies/TheAvengers -H "Content-Type: application/json" -d '{ "genre" : "scifi", "running_time" : "1.25" , "release_date" : "2010" }'

curl -X PUT http://riak:8098/riak/movies/TheAvatar -H "Content-Type: application/json" -d '{ "genre" : "fantasy", "running_time" : "2.05" , "release_date" : "2017" }'

curl -X PUT http://riak:8098/riak/movies/Apocalyto -H "Content-Type: application/json" -d '{ "genre" : "thriller", "running_time" : "1.45" , "release_date" : "2005" }'

curl -X PUT http://riak:8098/riak/movies/Troy -H "Content-Type: application/json" -d '{ "genre" : "Action", "running_time" : "1.45" , "release_date" : "2004" }'

curl -X PUT http://riak:8098/riak/movies/Ted -H "Content-Type: application/json" -d '{ "genre" : "comedy", "running_time" : "1.25" , "release_date" : "2008" }'

# 2. DELETE one movie

curl -X DELETE http://riak:8098/riak/movies/Apocalyto

curl -i http://riak:8098/riak/movies/Apocalyto

# 3.a CREATE Branches

# holds Troy
curl -X PUT http://riak:8098/riak/branches/East -H "Content-Type: application/json" -H "Link: </riak/movies/Troy>;riaktag=\"holds\"" -d '{ "name" : "East Branch" }'

# holds TheAvengers, TheAvatar
curl -X PUT http://riak:8098/riak/branches/West -H "Content-Type: application/json" -H "Link: </riak/movies/TheAvengers>;riaktag=\"holds\"" -H "Link: </riak/movies/TheAvatar>;riaktag=\"holds\"" -d '{ "name" : "West Branch" }'

# holds TheAvatar, Titanic, Ted
curl -X PUT http://riak:8098/riak/branches/South -H "Content-Type: application/json" -H "Link: </riak/movies/TheAvatar>;riaktag=\"holds\"" -H "Link: </riak/movies/Ted>;riaktag=\"holds\"" -H "Link: </riak/movies/Titanic>;riaktag=\"holds\"" -d '{ "name" : "South Branch" }'

# 4 Download images

curl -X PUT http://riak:8098/riak/images/TrojanHorse.jpeg -H "Content-Type: image/jpeg" --data-binary @TrojanHorse.jpeg

curl -i http://riak:8098/riak/images/TrojanHorse.jpeg

curl -X PUT http://riak:8098/riak/movies/Troy -H "Content-Type: application/json" -H "Link : </riak/images/TrojanHorse.jpeg>; riaktag=\"photo\"" -d '{ "genre" : "Action", "running_time" : "1.45" , "release_date" : "2004" }'

# 5.a Listing of all buckets and keys

curl http://riak:8098/riak?buckets=true
curl http://riak:8098/riak/movies?keys=true
curl http://riak:8098/riak/branches?keys=true
curl http://riak:8098/riak/images?keys=true

# 5.b Listing of all movies and branches

curl -i http://riak:8098/riak/movies/Titanic
curl -i http://riak:8098/riak/movies/TheAvengers
curl -i http://riak:8098/riak/movies/TheAvatar
curl -i http://riak:8098/riak/movies/Troy
curl -i http://riak:8098/riak/movies/Ted

curl -i http://riak:8098/riak/branches/West/_,_,_
curl -i http://riak:8098/riak/branches/South/_,_,_

# 5.c Listing of all movies with pictures and branch

curl -i http://riak:8098/riak/branches/East/_,_,_
curl -i http://riak:8098/riak/movies/Troy/_,_,_

curl -i http://riak:8098/riak/images/TrojanHorse.jpeg/_,_,_
