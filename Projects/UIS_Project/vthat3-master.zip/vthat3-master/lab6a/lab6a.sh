#!/usr/bin/env bash

#Add your curl statements here

curl -i -X PUT "http://couchdb:5984/restaurants"

curl -i -X POST "http://couchdb:5984/restaurants/" -H "Content-Type: application/json" -d '{"_id" : "taste_of_thai","name": "Taste of Thai","food_type" : ["Thai"], "phonenumber": "123456789", "website": "http://tasteofthai.com"}'
curl -i -X POST "http://couchdb:5984/restaurants/" -H "Content-Type: application/json" -d '{"_id" : "texas_de_brazil","name": "Texas De Brazil","food_type" : ["Mexican","American"], "phonenumber": "554432342", "website": "http://texasdebrazil.com"}'
curl -i -X POST "http://couchdb:5984/restaurants/" -H "Content-Type: application/json" -d '{"_id" : "home_of_pandas","name": "Home of Pandas","food_type" : ["Chinese"], "phonenumber": "888999456", "website": "http://homeofpandas.com"}'

#DO NOT REMOVE
curl -Ssf -X PUT http://couchdb:5984/restaurants/_design/docs -H "Content-Type: application/json" -d '{"views": {"all": {"map": "function(doc) {emit(doc._id, {rev:doc._rev, name:doc.name, food_type:doc.food_type, phonenumber:doc.phonenumber, website:doc.website})}"}}}'
curl -Ssf -X GET http://couchdb:5984/restaurants/_design/docs/_view/all
