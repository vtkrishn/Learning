# 1
db.user.insert({ _id : ObjectId('5bb26043708926e438db6cad'), name : 'Sam', email : 'samrocks@gmail.com'})
db.user.insert({ _id : ObjectId('5bb26043708926e438db6cae'), name : 'Alice', email : 'alicerocks@gmail.com'})
db.user.insert({ _id : ObjectId('5bb26043708926e438db6caf'), name : 'Rob', email : 'robrocks@gmail.com'})

# 2
db.user.find({_id : ObjectId('5bb26043708926e438db6cad')})

#3
db.blogs.insert({title : 'New Place visited - Mehu',body: '', slug: 'new-place-mehu', author : 'Alice', comments : [{
user_id : '5bb26043708926e438db6cad',
comment :'this post is super good',
approved: true,
created_at : '2017-10-10'
},
{
user_id : '5bb26043708926e438db6caf',
comment :'good post for everyone',
approved: true,
created_at : '2018-10-10'
}],
category : [{name : 'Travel'}]
})
db.blogs.insert({title : 'wonderful cheese cake', body: '',slug: 'cheese-cake-receipe', author : 'Sam', comments : [{
user_id : '5bb26043708926e438db6cae',
comment :'some information missing here',
approved: true,
created_at : '2017-10-10'
},
{
user_id : '5bb26043708926e438db6caf',
comment :'good post',
approved: true,
created_at : '2018-10-10'
}],
category : [{name : 'Food'}]
})
db.blogs.insert({title : 'Review about Iphone X', body: '',slug: 'iphone-x-review', author : 'Rob', comments : [{
user_id : '5bb26043708926e438db6cad',
comment :'Nice framework details',
approved: true,
created_at : '2018-10-10'
}],
category : [{name : 'Tech'}]
})

#4
db.blogs.find({'comments.user_id' : '5bb26043708926e438db6caf'},{title : 1, slug : 1})

#5
db.blogs.find({'comments.comment' : /Framework/i},{title : 1,'comments.comment':1})


db.blogs.find({'_id' :'5bb26043708926e438db6cai'})
